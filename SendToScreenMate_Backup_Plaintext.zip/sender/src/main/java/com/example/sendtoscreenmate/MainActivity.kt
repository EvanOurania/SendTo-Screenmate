package com.example.sendtoscreenmate

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.fromHtml
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.example.sendtoscreenmate.ui.theme.SendToScreenMateTheme
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class MainActivity : ComponentActivity() {

    private lateinit var repository: WebhookRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        val action = intent?.action
        val type = intent?.type
        val data = intent?.data

        val isShare = (action == Intent.ACTION_SEND && type == "text/plain")
        val isGeo = ((action == Intent.ACTION_VIEW || action == "android.intent.action.NAVIGATE") && data?.scheme == "geo")

        if (isShare || isGeo) {
            setTheme(R.style.Theme_SendToScreenMate_Transparent)
            window.setBackgroundDrawableResource(android.R.color.transparent)
            super.onCreate(savedInstanceState)
            
            repository = WebhookRepository(this)

            setContent {
                SendToScreenMateTheme {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.size(120.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(16.dp),
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = stringResource(R.string.sending_progress),
                                    style = MaterialTheme.typography.labelMedium,
                                )
                            }
                        }
                    }
                }
            }
            handleIncomingData(intent)
        } else {
            setTheme(R.style.Theme_SendToScreenMate)
            enableEdgeToEdge()
            super.onCreate(savedInstanceState)
            repository = WebhookRepository(this)

            setContent {
                SendToScreenMateTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background,
                    ) {
                        SettingsScreen(repository)
                    }
                }
            }
        }
    }

    private fun handleIncomingData(intent: Intent) {
        val extractedData = when (intent.action) {
            Intent.ACTION_SEND -> {
                val fullText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                extractUrl(fullText)
            }
            Intent.ACTION_VIEW, "android.intent.action.NAVIGATE" -> intent.dataString
            else -> null
        }

        if (extractedData != null) {
            lifecycleScope.launch {
                val serviceType = repository.serviceType.first()
                if (serviceType == WebhookRepository.SERVICE_MACRODROID) {
                    val url = repository.webhookUrl.first()
                    sendToMacroDroid(url, extractedData)
                } else {
                    val server = repository.ntfyServer.first()
                    val topic = repository.ntfyTopic.first()
                    sendToNtfy(server, topic, extractedData)
                }
            }
        } else {
            Toast.makeText(this, getString(R.string.no_data_error), Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun extractUrl(text: String): String {
        val urlRegex = Regex("(https?://\\S+)")
        val match = urlRegex.find(text)
        return match?.value ?: text
    }

    private fun sendToMacroDroid(webhookUrl: String, text: String) {
        lifecycleScope.launch {
            val success = withContext(Dispatchers.IO) {
                try {
                    val client = OkHttpClient()
                    val url = webhookUrl.toHttpUrlOrNull()
                        ?.newBuilder()
                        ?.addQueryParameter("value", text)
                        ?.build()

                    if (url != null) {
                        val request = Request.Builder()
                            .url(url)
                            .get()
                            .build()

                        client.newCall(request).execute().use { response ->
                            response.isSuccessful
                        }
                    } else {
                        false
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
            }

            if (success) {
                Toast.makeText(this@MainActivity, getString(R.string.sent_macrodroid), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, getString(R.string.error_macrodroid), Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

    private fun sendToNtfy(server: String, topic: String, text: String) {
        lifecycleScope.launch {
            val success = withContext(Dispatchers.IO) {
                try {
                    val client = OkHttpClient()
                    val baseUrl = if (server.endsWith("/")) server else "$server/"
                    val finalUrl = "$baseUrl$topic"
                    
                    val request = Request.Builder()
                        .url(finalUrl)
                        .post(text.toRequestBody("text/plain".toMediaType()))
                        .build()

                    client.newCall(request).execute().use { response ->
                        response.isSuccessful
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
            }

            if (success) {
                Toast.makeText(this@MainActivity, getString(R.string.sent_ntfy), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, getString(R.string.error_ntfy), Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(repository: WebhookRepository) {
    val currentService by repository.serviceType.collectAsState(initial = WebhookRepository.SERVICE_MACRODROID)
    val savedMacroDroidUrl by repository.webhookUrl.collectAsState(initial = WebhookRepository.DEFAULT_URL)
    val savedNtfyServer by repository.ntfyServer.collectAsState(initial = WebhookRepository.DEFAULT_NTFY_SERVER)
    val savedNtfyTopic by repository.ntfyTopic.collectAsState(initial = "")

    var macroDroidUrl by remember { mutableStateOf("") }
    var ntfyServer by remember { mutableStateOf("") }
    var ntfyTopic by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()

    LaunchedEffect(savedMacroDroidUrl, savedNtfyServer, savedNtfyTopic) {
        macroDroidUrl = savedMacroDroidUrl
        ntfyServer = savedNtfyServer
        ntfyTopic = savedNtfyTopic
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(stringResource(R.string.settings_title)) })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Service Selection
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.select_service), style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    ServiceRadioButton(
                        label = "MacroDroid",
                        selected = currentService == WebhookRepository.SERVICE_MACRODROID,
                    ) {
                        scope.launch { repository.saveServiceType(WebhookRepository.SERVICE_MACRODROID) }
                    }
                    ServiceRadioButton(
                        label = "ntfy.sh",
                        selected = currentService == WebhookRepository.SERVICE_NTFY,
                    ) {
                        scope.launch { repository.saveServiceType(WebhookRepository.SERVICE_NTFY) }
                    }
                }
            }

            HorizontalDivider()

            if (currentService == WebhookRepository.SERVICE_MACRODROID) {
                // MacroDroid Settings
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(stringResource(R.string.macrodroid_config), style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = macroDroidUrl,
                        onValueChange = { macroDroidUrl = it },
                        label = { Text(stringResource(R.string.webhook_url_label)) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                repository.saveWebhookUrl(macroDroidUrl)
                                Toast.makeText(repository.context, R.string.save_success_macrodroid, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(stringResource(R.string.save_macrodroid))
                    }
                    
                    Text(
                        text = AnnotatedString.fromHtml(stringResource(R.string.macrodroid_instructions)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // ntfy Settings
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(stringResource(R.string.ntfy_config), style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = ntfyServer,
                        onValueChange = { ntfyServer = it },
                        label = { Text(stringResource(R.string.ntfy_server_label)) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = ntfyTopic,
                        onValueChange = { ntfyTopic = it },
                        label = { Text(stringResource(R.string.ntfy_topic_label)) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                repository.saveNtfyServer(ntfyServer)
                                repository.saveNtfyTopic(ntfyTopic)
                                Toast.makeText(repository.context, R.string.save_success_ntfy, Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(stringResource(R.string.save_ntfy))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val context = LocalContext.current
                    val scannerLauncher = rememberLauncherForActivityResult(
                        ScanContract()
                    ) { result ->
                        if (result.contents != null) {
                            val scannedData = result.contents
                            Log.d("QR_SCAN", "Raw data: $scannedData")

                            if (scannedData.contains("|")) {
                                // New robust format: server|topic
                                val parts = scannedData.split("|")
                                if (parts.size == 2) {
                                    val serverUrl = parts[0]
                                    val topicPath = parts[1]

                                    scope.launch {
                                        repository.saveNtfyServer(serverUrl)
                                        repository.saveNtfyTopic(topicPath)
                                        ntfyServer = serverUrl
                                        ntfyTopic = topicPath
                                        Toast.makeText(context, R.string.save_success_ntfy, Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else if (scannedData.startsWith("ntfy://")) {
                                // Fallback for old URI format with robust manual parsing
                                val cleanData = scannedData.removePrefix("ntfy://").trim('/')
                                val serverUrl: String
                                val topicPath: String

                                if (cleanData.contains("/")) {
                                    serverUrl = "https://" + cleanData.substringBefore("/")
                                    topicPath = cleanData.substringAfter("/")
                                } else {
                                    serverUrl = "https://ntfy.sh"
                                    topicPath = cleanData
                                }

                                scope.launch {
                                    repository.saveNtfyServer(serverUrl)
                                    repository.saveNtfyTopic(topicPath)
                                    ntfyServer = serverUrl
                                    ntfyTopic = topicPath
                                    Toast.makeText(context, R.string.save_success_ntfy, Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }

                    val scanPrompt = stringResource(R.string.scan_qr)
                    OutlinedButton(
                        onClick = {
                            val options = ScanOptions()
                            options.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                            options.setPrompt(scanPrompt)
                            options.setBeepEnabled(false)
                            options.setOrientationLocked(true)
                            options.captureActivity = CaptureActivityPortrait::class.java
                            scannerLauncher.launch(options)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(stringResource(R.string.scan_qr))
                    }
                    
                    Text(
                        text = AnnotatedString.fromHtml(stringResource(R.string.ntfy_instructions)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ServiceRadioButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text = label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(start = 4.dp))
    }
}
